package com.hexaware.hms.dao;

import com.hexaware.hms.entity.Appointment;
import com.hexaware.hms.exception.PatientNumberNotFoundException;

import java.util.List;

public interface IHospitalService {
	Appointment getAppointmentById(int appointmentId);

	List<Appointment> getAppointmentsForPatient(int patientId) throws PatientNumberNotFoundException;

	List<Appointment> getAppointmentsForDoctor(int doctorId);

	boolean scheduleAppointment(Appointment appointment);

	boolean updateAppointment(Appointment appointment);

	boolean cancelAppointment(int appointmentId);
}
