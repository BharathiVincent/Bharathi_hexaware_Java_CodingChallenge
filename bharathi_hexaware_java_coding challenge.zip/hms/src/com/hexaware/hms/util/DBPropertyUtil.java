package com.hexaware.hms.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class DBPropertyUtil {
	public static String getPropertyString(String fileName) {
		Properties properties = new Properties();
		try (FileInputStream fis = new FileInputStream(fileName)) {
			properties.load(fis);
			return "jdbc:mysql://localhost:3306/hms" + properties.getProperty("localhost") + ":" + properties.getProperty("3306") + "/"
					+ properties.getProperty("hms") + "user" + properties.getProperty("root") + "password"
					+ properties.getProperty("Vins@5545");
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
}
