/**
 * 
 */
/**
 * 
 */
module hms {
	requires java.sql;
}